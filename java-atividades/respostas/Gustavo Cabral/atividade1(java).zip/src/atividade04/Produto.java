package atividade04;

public class Produto {
    String nome;
    double preco;
    int quantidade;

    Produto(String nome, double preco, int quantidade) {
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    double calcularValorEstoque() {
        return preco * quantidade;
    }

    void exibirProduto() {
        System.out.println("Produto: " + nome);
        System.out.println("Preço: R$ " + preco);
        System.out.println("Quantidade: " + quantidade);
        System.out.println("Valor em estoque: R$ " + calcularValorEstoque());
        System.out.println("---------------------");
    }

    // desafio: desconto em porcentagem
    void aplicarDesconto(double percentual) {
        if (percentual > 0 && percentual <= 100) {
            preco = preco - (preco * percentual / 100);
            System.out.println("Desconto de " + percentual + "% aplicado em " + nome);
        } else {
            System.out.println("Percentual inválido.");
        }
    }

    public static void main(String[] args) {
        Produto p1 = new Produto("Teclado", 80.0, 10);
        Produto p2 = new Produto("Mouse", 40.0, 25);
        Produto p3 = new Produto("Monitor", 700.0, 5);

        p1.exibirProduto();
        p2.exibirProduto();
        p3.exibirProduto();

        p3.aplicarDesconto(10);
        p3.exibirProduto();
    }
}
