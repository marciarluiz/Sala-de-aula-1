package atividade13;

public class ArCondicionado {
    String marca;
    int temperatura;
    boolean ligado;

    void ligar() {
        ligado = true;
        System.out.println("Ar-condicionado ligado.");
    }

    void desligar() {
        ligado = false;
        System.out.println("Ar-condicionado desligado.");
    }

    void aumentarTemperatura() {
        if (!ligado) {
            System.out.println("Ligue o aparelho primeiro.");
        } else if (temperatura < 30) {
            temperatura++;
        } else {
            System.out.println("Temperatura já está no máximo (30 °C).");
        }
    }

    void diminuirTemperatura() {
        if (!ligado) {
            System.out.println("Ligue o aparelho primeiro.");
        } else if (temperatura > 16) {
            temperatura--;
        } else {
            System.out.println("Temperatura já está no mínimo (16 °C).");
        }
    }

    void exibirInformacoes() {
        System.out.println(marca + " | " + (ligado ? "ligado" : "desligado") + " | " + temperatura + " °C");
    }

    public static void main(String[] args) {
        ArCondicionado ar = new ArCondicionado();
        ar.marca = "Samsung";
        ar.temperatura = 29;

        ar.aumentarTemperatura(); // desligado, não deve mudar
        ar.ligar();
        ar.exibirInformacoes();

        ar.aumentarTemperatura();
        ar.aumentarTemperatura(); // passou de 30
        ar.exibirInformacoes();

        ar.temperatura = 17;
        ar.diminuirTemperatura();
        ar.diminuirTemperatura(); // passou de 16
        ar.exibirInformacoes();

        ar.desligar();
        ar.exibirInformacoes();
    }
}
