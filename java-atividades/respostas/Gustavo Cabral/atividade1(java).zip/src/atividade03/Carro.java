package atividade03;

public class Carro {
    String modelo;
    String marca;
    int ano;
    boolean ligado;

    void ligar() {
        if (ligado) {
            System.out.println(modelo + " já está ligado!");
        } else {
            ligado = true;
            System.out.println(modelo + " foi ligado.");
        }
    }

    void desligar() {
        if (!ligado) {
            System.out.println(modelo + " já está desligado!");
        } else {
            ligado = false;
            System.out.println(modelo + " foi desligado.");
        }
    }

    void exibirInformacoes() {
        System.out.println(marca + " " + modelo + " (" + ano + ") - " + (ligado ? "ligado" : "desligado"));
    }

    public static void main(String[] args) {
        Carro c1 = new Carro();
        c1.modelo = "Onix";
        c1.marca = "Chevrolet";
        c1.ano = 2022;

        Carro c2 = new Carro();
        c2.modelo = "Civic";
        c2.marca = "Honda";
        c2.ano = 2020;

        c1.exibirInformacoes();
        c1.ligar();
        c1.ligar(); // tentando ligar de novo
        c1.exibirInformacoes();
        c1.desligar();

        System.out.println();

        c2.exibirInformacoes();
        c2.ligar();
        c2.exibirInformacoes();
        c2.desligar();
        c2.desligar();
    }
}
