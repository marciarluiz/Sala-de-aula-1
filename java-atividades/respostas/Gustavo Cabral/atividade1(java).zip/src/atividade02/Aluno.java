package atividade02;

public class Aluno {
    String nome;
    int idade;
    String curso;
    String matricula; // desafio

    void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Curso: " + curso);
        System.out.println("Matrícula: " + matricula);
        System.out.println("---------------------");
    }

    public static void main(String[] args) {
        Aluno a1 = new Aluno();
        a1.nome = "Ana";
        a1.idade = 19;
        a1.curso = "Sistemas de Informação";
        a1.matricula = "2026001";

        Aluno a2 = new Aluno();
        a2.nome = "Bruno";
        a2.idade = 21;
        a2.curso = "Engenharia";
        a2.matricula = "2026002";

        Aluno a3 = new Aluno();
        a3.nome = "Carla";
        a3.idade = 20;
        a3.curso = "Administração";
        a3.matricula = "2026003";

        a1.exibirDados();
        a2.exibirDados();
        a3.exibirDados();
    }
}
