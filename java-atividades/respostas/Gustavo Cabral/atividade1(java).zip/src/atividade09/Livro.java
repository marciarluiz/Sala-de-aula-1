package atividade09;

public class Livro {
    String titulo;
    String autor;
    int numeroPaginas;

    void abrirLivro() {
        System.out.println("Abrindo o livro \"" + titulo + "\"...");
    }

    void fecharLivro() {
        System.out.println("Fechando o livro \"" + titulo + "\".");
    }

    void mostrarDetalhes() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Páginas: " + numeroPaginas);
        System.out.println("---------------------");
    }

    public static void main(String[] args) {
        Livro l1 = new Livro();
        l1.titulo = "Dom Casmurro";
        l1.autor = "Machado de Assis";
        l1.numeroPaginas = 256;

        Livro l2 = new Livro();
        l2.titulo = "O Pequeno Príncipe";
        l2.autor = "Antoine de Saint-Exupéry";
        l2.numeroPaginas = 96;

        Livro l3 = new Livro();
        l3.titulo = "Capitães da Areia";
        l3.autor = "Jorge Amado";
        l3.numeroPaginas = 280;

        l1.mostrarDetalhes();
        l2.mostrarDetalhes();
        l3.mostrarDetalhes();

        l1.abrirLivro();
        l1.fecharLivro();
        l2.abrirLivro();
        l2.fecharLivro();
        l3.abrirLivro();
        l3.fecharLivro();
    }
}
