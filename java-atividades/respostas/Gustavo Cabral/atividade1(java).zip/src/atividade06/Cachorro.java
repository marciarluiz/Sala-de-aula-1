package atividade06;

public class Cachorro {
    String nome;
    String raca;
    int idade;

    void latir() {
        System.out.println(nome + " está latindo: Au au!");
    }

    void brincar() {
        System.out.println(nome + " está brincando com a bolinha.");
    }

    void exibirDados() {
        System.out.println("Nome: " + nome + " | Raça: " + raca + " | Idade: " + idade + " anos");
    }

    public static void main(String[] args) {
        Cachorro c1 = new Cachorro();
        c1.nome = "Rex";
        c1.raca = "Pastor Alemão";
        c1.idade = 4;

        Cachorro c2 = new Cachorro();
        c2.nome = "Bolt";
        c2.raca = "Labrador";
        c2.idade = 2;

        Cachorro c3 = new Cachorro();
        c3.nome = "Luna";
        c3.raca = "Poodle";
        c3.idade = 6;

        c1.exibirDados();
        c1.latir();
        c1.brincar();
        System.out.println();

        c2.exibirDados();
        c2.latir();
        c2.brincar();
        System.out.println();

        c3.exibirDados();
        c3.latir();
        c3.brincar();
    }
}
