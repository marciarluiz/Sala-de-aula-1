package atividade01;

public class ContaBancaria {
    String titular;
    int numeroConta;
    double saldo;

    void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
            System.out.println("Depósito de R$ " + valor + " realizado.");
        } else {
            System.out.println("Valor de depósito inválido.");
        }
    }

    void sacar(double valor) {
        if (valor <= 0) {
            System.out.println("Valor de saque inválido.");
        } else if (valor > saldo) {
            System.out.println("Saldo insuficiente para sacar R$ " + valor);
        } else {
            saldo -= valor;
            System.out.println("Saque de R$ " + valor + " realizado.");
        }
    }

    void exibirSaldo() {
        System.out.println("Titular: " + titular + " | Conta: " + numeroConta + " | Saldo: R$ " + saldo);
    }

    public static void main(String[] args) {
        ContaBancaria conta1 = new ContaBancaria();
        conta1.titular = "Maria Souza";
        conta1.numeroConta = 12345;
        conta1.saldo = 500;

        conta1.exibirSaldo();
        conta1.depositar(200);
        conta1.sacar(100);
        conta1.sacar(1000); // vai dar erro de propósito, só pra testar
        conta1.exibirSaldo();
    }
}
